/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package antcolony;

/**
 *
 * @author brandon
 */
public class Location {
    // bala enemyAnt;
    Ant friendlyAnt;
    int foodUnits;
    int pheremoneUnits;
    Coordinates coordinates;
    boolean isOpen;
    boolean isEntrance;
    
    public static void initLocation() {
        
    }
    
    public static void updateLocation() {
        
    }
}
